﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace asztallok
{
    public partial class FormNyito : Form
    {
        public FormNyito()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            updateList();          
        }

        private void button_insert_Click(object sender, EventArgs e)
        {
            new FormInsert().ShowDialog();
            updateList();

        }

        private void button_update_Click(object sender, EventArgs e)
        {
            new FormUpdate().ShowDialog();
            updateList();
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            removeFruit(getSelectedFruit());
            updateList();

        }

        public asztal getSelectedFruit()
        {
            return (asztal)comboBox_fruits.SelectedItem;
        }

        public void updateList()
        {
            comboBox_fruits.Items.Clear();
            foreach (var item in getAllFruits())
                comboBox_fruits.Items.Add(item);
            if (comboBox_fruits.Items.Count != 0)
                comboBox_fruits.SelectedIndex = 0;
        }

        private List<asztal> getAllFruits()
        {
            var res = Program.database.Query("SELECT `id`, `nev`, `egysegar`, `mennyiseg` FROM `gyumolcs`;");
            List<asztal> fruits = new List<asztal>();
            foreach (var item in res.Values)
            {
                var id = int.Parse(item[0]);
                var name = item[1];
                var price = int.Parse(item[2]);
                var quantity = int.Parse(item[3]);
                fruits.Add(new asztal(id, name, price, quantity));
            }
            return fruits;
        }

        private void removeFruit(asztal fruit)
        {
            Program.database.Query("DELETE FROM gyumolcs WHERE `gyumolcs`.`id` = @1;", fruit.Id);
        }

    }
}
